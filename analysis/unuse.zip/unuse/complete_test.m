% 完整测试脚本
% 本文件包含所有必要的函数定义，可直接运行

% 常量定义
global a_n b_n a_p b_p q eps0 eps_r eps_s;
a_n = 7.03e5;        % cm^-1
b_n = 1.231e6;       % V/cm
a_p = 1.582e6;       % cm^-1
b_p = 2.036e6;       % V/cm
q = 1.602e-19;       % C
eps0 = 8.854e-14;    % F/cm
eps_r = 11.7;
eps_s = eps0 * eps_r;

% 计算电子电离系数
function an = alpha_n(E)
global a_n b_n;
E = max(E, 1e-12);  % 避免除以零
an = a_n * exp(-b_n ./ E);
end

% 计算空穴电离系数
function ap = alpha_p(E)
global a_p b_p;
E = max(E, 1e-12);  % 避免除以零
ap = a_p * exp(-b_p ./ E);
end

% 计算电离积分
function I = ionization_integral_for_W(W_cm, BV, grid_points)
% 生成空间网格（确保是列向量）
x = linspace(0, W_cm, grid_points)';
% 计算电场分布
E = 2.0 * BV * (W_cm - x) / (W_cm^2);
% 计算电离系数
an = alpha_n(E);
% 确保an是列向量
an = an(:);
% 计算差值
diff = an - alpha_p(E);
% 确保diff是列向量
diff = diff(:);
% 累积积分
S = cumtrapz(x, diff);
% 确保S是列向量
S = S(:);
% 确保S的长度与x相同
if length(S) < length(x)
    S = [0; S];
end
% 截断或填充S，确保长度与an相同
S = S(1:length(an));
% 计算被积函数
integrand = an .* exp(-S);
% 计算积分
I = trapz(x, integrand);
end

% 求解给定BV下的W
function W = solve_W_for_BV(BV, Wmin_cm, Wmax_cm, grid_points)
% 定义目标函数
f = @(W) ionization_integral_for_W(W, BV, grid_points) - 1.0;
% 使用fzero求解
W = fzero(f, [Wmin_cm, Wmax_cm]);
end

% 计算所有BV对应的W和N
function [BV, W_cm, N] = compute_all(varargin)
global eps_s q;
% 设置默认参数
if nargin < 1
    BV_list = linspace(400, 1600, 41);  % 默认BV范围
else
    BV_list = varargin{1};
end

if nargin < 2
    grid_points = 20000;  % 默认网格点数
else
    grid_points = varargin{2};
end

% 参数检查
if ~isvector(BV_list)
    error('BV_list must be a vector');
end

if grid_points <= 0
    error('grid_points must be positive');
end

W_solutions = [];
N_solutions = [];

for i = 1:length(BV_list)
    current_BV = BV_list(i);
    % 使用Fulop近似作为初始猜测
    W_fulop_um = 0.0257 * (current_BV^(7.0/6.0));
    W_guess_cm = W_fulop_um * 1e-4;
    Wmin = max(1e-6, W_guess_cm * 0.2);
    Wmax = max(Wmin*10, W_guess_cm * 4.0);

    try
        W = solve_W_for_BV(current_BV, Wmin, Wmax, grid_points);
    catch
        % 扩大搜索范围
        W = solve_W_for_BV(current_BV, Wmin*0.05, Wmax*20, grid_points);
    end

    % 计算N
    N_val = 2.0 * eps_s * current_BV / (q * W^2);
    W_solutions = [W_solutions, W];
    N_solutions = [N_solutions, N_val];
end

BV = BV_list;
W_cm = W_solutions;
N = N_solutions;
end

% 主测试函数
function main_test()
% 测试alpha_n和alpha_p函数
disp('测试alpha_n和alpha_p函数:');
E_test = 1e6;  % V/cm
an_test = alpha_n(E_test);
ap_test = alpha_p(E_test);
disp(['E = ', num2str(E_test), ' V/cm:']);
disp(['alpha_n = ', num2str(an_test), ' cm^-1']);
disp(['alpha_p = ', num2str(ap_test), ' cm^-1']);

% 测试ionization_integral_for_W函数
disp('\n测试ionization_integral_for_W函数:');
W_test = 1e-4;  % 10 μm in cm
BV_test = 1000;  % V
grid_points = 1000;
I_test = ionization_integral_for_W(W_test, BV_test, grid_points);
disp(['W = ', num2str(W_test*1e4), ' μm, BV = ', num2str(BV_test), ' V:']);
disp(['Ionization integral = ', num2str(I_test)]);

% 测试solve_W_for_BV函数
disp('\n测试solve_W_for_BV函数:');
BV_test = 1000;  % V
W_fulop_um = 0.0257 * (BV_test^(7.0/6.0));
W_guess_cm = W_fulop_um * 1e-4;
Wmin = max(1e-6, W_guess_cm * 0.2);
Wmax = max(Wmin*10, W_guess_cm * 4.0);
W_solution = solve_W_for_BV(BV_test, Wmin, Wmax, 10000);
disp(['BV = ', num2str(BV_test), ' V:']);
disp(['Solution W = ', num2str(W_solution*1e4), ' μm']);

% 运行完整计算
disp('\n运行完整计算 (小范围测试):');
BV_list = [500, 1000, 1500];
[BV, W_cm, N] = compute_all(BV_list, 10000);
W_um = W_cm * 1e4;
disp('BV (V) | W (μm) | N (cm^-3)');
disp('-----------------------------');
for i = 1:length(BV)
    disp([num2str(BV(i)), ' | ', num2str(W_um(i), '%.4f'), ' | ', num2str(N(i), '%.2e')]);
end

% 测试默认参数
disp('\n测试默认参数:');
[BV_default, W_default, N_default] = compute_all();
disp(['默认参数计算点数: ', num2str(length(BV_default))]);
disp(['第一个BV值: ', num2str(BV_default(1)), ' V']);
disp(['最后一个BV值: ', num2str(BV_default(end)), ' V']);

% 输出测试完成信息
disp('\n测试完成！');
end

% 执行测试
main_test();