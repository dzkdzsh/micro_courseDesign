% 运行main函数的脚本
% 本文件用于测试main_function函数的正常运行

% 先运行main_function.m文件加载所有函数
run('main_function.m');

% 直接实现main函数的功能
% 设置参数
grid_points = 20000;
BV_list = linspace(400, 1600, 41);

% 计算W和N
[BV, W_cm, N] = compute_all(BV_list, grid_points);

% 转换单位
W_um = W_cm * 1e4;  % 转换为μm

% 拟合N与BV的关系
log_BV = log(BV);
log_N = log(N);
p_N = polyfit(log_BV, log_N, 1);
C_N = exp(p_N(2));

% 拟合W与BV的关系
log_W = log(W_um);
p_W = polyfit(log_BV, log_W, 1);
C_W = exp(p_W(2));

% 拟合W与N的关系
log_N_vals = log(N);
p_NW = polyfit(log_N_vals, log_W, 1);
C_NW = exp(p_NW(2));

% 输出结果
disp('拟合结果 (MATLAB数值拟合):');
disp(['W ≈ ', num2str(C_W, '%.5g'), ' * BV^', num2str(p_W(1), '%.5f'), ' μm']);
disp(['N ≈ ', num2str(C_N, '%.5g'), ' * BV^', num2str(p_N(1), '%.5f'), ' cm^-3']);
disp(['W ≈ ', num2str(C_NW, '%.5g'), ' * N^', num2str(p_NW(1), '%.5f'), ' μm']);

% 保存数据
data = [BV; W_um; N]';
writematrix(data, 'BV_W_N.mat', 'Delimiter', ' ');
writematrix(data, 'BV_W_N.csv', 'Delimiter', ',');

% 不同区间的拟合
ranges = {[400,1600], [400,1200], [400,1000], [500,1600], [600,1600], [400,800]};
disp('\n不同区间的拟合结果:');
for i = 1:length(ranges)
  range = ranges{i};
  mask = (BV >= range(1)) & (BV <= range(2));
  if any(mask)
    p_range = polyfit(log_BV(mask), log_N(mask), 1);
    C_range = exp(p_range(2));
    disp(['range ', num2str(range(1)), '-', num2str(range(2)), ': exponent=', num2str(p_range(1), '%.6f'), ', C=', num2str(C_range, '%.6g')]);
  end
end

% 使用示例
disp('\n使用示例:');
disp('1. 运行完整计算: 直接运行本脚本');
disp('2. 计算特定BV范围: [BV, W, N] = compute_all([500, 1000, 1500], 10000);');
disp('3. 使用默认参数: [BV, W, N] = compute_all();');