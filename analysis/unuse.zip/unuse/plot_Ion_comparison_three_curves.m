% 绘制电离积分Ion(V)三曲线对比图
% 对比：1) Medici仿真结果  2) 原MATLAB计算(W=70μm, N=2.7901e14)  3) 新MATLAB计算(W=55.2327μm, N=2.7557e14, BV=650V)

%% 常量定义
global a_n b_n a_p b_p q eps0 eps_r eps_s;
a_n = 7.03e5;        % cm^-1
b_n = 1.231e6;       % V/cm
a_p = 1.582e6;       % cm^-1
b_p = 2.036e6;       % V/cm
q = 1.602e-19;       % C
eps0 = 8.854e-14;    % F/cm
eps_r = 11.7;
eps_s = eps0 * eps_r;

%% 器件参数
% 原参数（用户给定的70μm参数）
W_cm_old = 70e-4;        % 70 μm
N_dop_old = 2.7901e14;   % cm^-3
BV_old = 646.1;          % Medici实际击穿电压

% 新参数（BV=650V解得的参数）
W_cm_new = 55.2327e-4;   % 55.2327 μm
N_dop_new = 2.7557e14;   % cm^-3
BV_new = 650;            % V

grid_points = 20000;

%% 计算电子电离系数
function an = alpha_n(E)
global a_n b_n;
    E = max(E, 1e-12);
    an = a_n * exp(-b_n ./ E);
end

%% 计算空穴电离系数
function ap = alpha_p(E)
global a_p b_p;
    E = max(E, 1e-12);
    ap = a_p * exp(-b_p ./ E);
end

%% 计算给定外加电压V下的电离积分（原方法，耗尽区变化）
function I = ionization_integral_old(V, W_cm, N_dop, BV, grid_points)
global eps_s q;
    % 计算耗尽区宽度 W_d = W * sqrt(V/BV) (当 V <= BV)
    if V <= BV && V > 0
        W_d = W_cm * sqrt(V / BV);
    elseif V > BV
        W_d = W_cm;
    else
        I = 0;
        return;
    end

    if W_d > 1e-10
        x = linspace(0, W_d, grid_points)';
        E = q * N_dop * (W_d - x) / eps_s;
        an = alpha_n(E); an = an(:);
        ap = alpha_p(E); ap = ap(:);
        diff = an - ap; diff = diff(:);
        S = cumtrapz(x, diff); S = S(:);
        if length(S) < length(x), S = [0; S]; end
        S = S(1:length(an));
        integrand = an .* exp(-S);
        I = trapz(x, integrand);
    else
        I = 0;
    end
end

%% 计算给定外加电压V下的电离积分（新方法，固定W，电场随V变化）
function I = ionization_integral_new(V, W_cm, BV, grid_points)
    % 使用电场分布 E(x) = 2*V*(W-x)/W^2
    % 当V = BV时，电离积分应该等于1
    if V <= 0
        I = 0;
        return;
    end

    x = linspace(0, W_cm, grid_points)';
    E = 2.0 * V * (W_cm - x) / (W_cm^2);
    an = alpha_n(E); an = an(:);
    ap = alpha_p(E); ap = ap(:);
    diff = an - ap; diff = diff(:);
    S = cumtrapz(x, diff); S = S(:);
    if length(S) < length(x), S = [0; S]; end
    S = S(1:length(an));
    integrand = an .* exp(-S);
    I = trapz(x, integrand);
end

%% 读取Medici仿真数据
excel_file = 'd:\micro_courseDesign\仿真\设定650_步长0.2_击穿电压646.1\设定650_步长0.2_击穿电压646.1.xlsx';
medici_data = readtable(excel_file);
V_medici = medici_data.('VoltageV_K__V_');
Ion_medici = medici_data.('ExtractedExpression_testn_');

%% 计算MATLAB电离积分
V_calc = linspace(0, max(V_medici), 200)';
Ion_old = zeros(size(V_calc));
Ion_new = zeros(size(V_calc));

fprintf('计算MATLAB电离积分...\n');
for i = 1:length(V_calc)
    V = V_calc(i);
    % 原方法计算
    Ion_old(i) = ionization_integral_old(V, W_cm_old, N_dop_old, BV_old, grid_points);
    % 新方法计算
    Ion_new(i) = ionization_integral_new(V, W_cm_new, BV_new, grid_points);
end

fprintf('原方法 (W=70μm): 在V=646.1V时, Ion=%.4f\n', ionization_integral_old(646.1, W_cm_old, N_dop_old, BV_old, grid_points));
fprintf('新方法 (W=55.23μm): 在V=650V时, Ion=%.4f\n', ionization_integral_new(650, W_cm_new, BV_new, grid_points));

%% 绘图
figure('Position', [100, 100, 900, 650]);

% Medici仿真数据 - 散点图
scatter(V_medici, Ion_medici, 40, 'r', 'filled', 'MarkerFaceAlpha', 0.5, 'DisplayName', 'Medici Simulation');
hold on;

% 原MATLAB计算 - 蓝色虚线
plot(V_calc, Ion_old, 'b--', 'LineWidth', 1.5, 'DisplayName', 'MATLAB (W=70μm, N=2.79×10^{14}cm^{-3})');

% 新MATLAB计算 - 绿色实线
plot(V_calc, Ion_new, 'g-', 'LineWidth', 2, 'DisplayName', 'MATLAB (W=55.23μm, N=2.76×10^{14}cm^{-3}, BV=650V)');

% 添加击穿电压标记线
xline(646.1, '--k', 'LineWidth', 1, 'Alpha', 0.4);
xline(650, ':k', 'LineWidth', 1, 'Alpha', 0.4);

% 添加Ion=1的水平线
yline(1, '-.k', 'LineWidth', 1, 'Alpha', 0.4, 'DisplayName', 'I_{on}=1');

hold off;

% 设置坐标轴
xlabel('Applied Voltage V (V)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Ionization Integral I_{on}', 'FontSize', 14, 'FontWeight', 'bold');
title('Ionization Integral vs Applied Voltage (Comparison)', 'FontSize', 16, 'FontWeight', 'bold');

% 设置图例
legend('Location', 'northwest', 'FontSize', 11);

% 设置网格
grid on;
set(gca, 'FontSize', 12, 'LineWidth', 1.5);

% 设置坐标轴范围
xlim([0, max(V_medici)*1.02]);
ylim([0, max(max(Ion_medici), max(Ion_new))*1.05]);

% 添加击穿电压标注
text(646.1, 0.05, '  646.1V', 'FontSize', 10, 'Color', 'k');
text(650, 0.12, '  650V', 'FontSize', 10, 'Color', 'k');

%% 保存图片
plot_dir = 'd:\micro_courseDesign\plot';
if ~exist(plot_dir, 'dir')
    mkdir(plot_dir);
end

% 保存为PNG
saveas(gcf, fullfile(plot_dir, 'Ion_V_comparison_three_curves.png'));
% 保存为JPG
saveas(gcf, fullfile(plot_dir, 'Ion_V_comparison_three_curves.jpg'));

fprintf('\n图片已保存到: %s\n', plot_dir);
fprintf('  - Ion_V_comparison_three_curves.png\n');
fprintf('  - Ion_V_comparison_three_curves.jpg\n');

%% 显示关键数据点对比
fprintf('\n关键数据点对比:\n');
fprintf('%-10s %-18s %-18s %-18s\n', 'V (V)', 'Medici Ion', 'MATLAB Old', 'MATLAB New');
fprintf('%s\n', repmat('-', 1, 70));

key_V = [100, 300, 500, 600, 640, 646.1, 650, 700];
for V_target = key_V
    [~, idx_med] = min(abs(V_medici - V_target));
    [~, idx_calc] = min(abs(V_calc - V_target));
    V_val = V_medici(idx_med);
    Ion_med = Ion_medici(idx_med);
    Ion_old_val = Ion_old(idx_calc);
    Ion_new_val = Ion_new(idx_calc);
    fprintf('%-10.1f %-18.6f %-18.6f %-18.6f\n', V_val, Ion_med, Ion_old_val, Ion_new_val);
end

%% 计算与Medici的误差
fprintf('\n与Medici仿真结果的误差 (%%):\n');
fprintf('%-10s %-18s %-18s\n', 'V (V)', 'Old MATLAB', 'New MATLAB');
fprintf('%s\n', repmat('-', 1, 50));

for V_target = [646.1, 650]
    [~, idx_med] = min(abs(V_medici - V_target));
    [~, idx_calc] = min(abs(V_calc - V_target));
    V_val = V_medici(idx_med);
    Ion_med = Ion_medici(idx_med);
    Ion_old_val = Ion_old(idx_calc);
    Ion_new_val = Ion_new(idx_calc);

    err_old = abs(Ion_old_val - Ion_med) / Ion_med * 100;
    err_new = abs(Ion_new_val - Ion_med) / Ion_med * 100;
    fprintf('%-10.1f %-18.2f %-18.2f\n', V_val, err_old, err_new);
end
