% 核心函数实现
% 本文件包含计算电离系数、电离积分和求解W的核心函数

% 常量定义
global a_n b_n a_p b_p q eps0 eps_r eps_s;
a_n = 7.03e5;        % cm^-1
b_n = 1.231e6;       % V/cm
a_p = 1.582e6;       % cm^-1
b_p = 2.036e6;       % V/cm
q = 1.602e-19;       % C
eps0 = 8.854e-14;    % F/cm
eps_r = 11.7;
eps_s = eps0 * eps_r;

% 计算电子电离系数
function an = alpha_n(E)
global a_n b_n;
E = max(E, 1e-12);  % 避免除以零
an = a_n * exp(-b_n ./ E);
end

% 计算空穴电离系数
function ap = alpha_p(E)
global a_p b_p;
E = max(E, 1e-12);  % 避免除以零
ap = a_p * exp(-b_p ./ E);
end

% 计算电离积分
function I = ionization_integral_for_W(W_cm, BV, grid_points)
% 生成空间网格
x = linspace(0, W_cm, grid_points);
% 计算电场分布
E = 2.0 * BV * (W_cm - x) / (W_cm^2);
% 计算电离系数
an = alpha_n(E);
ap = alpha_p(E);
% 计算差值
diff = an - ap;
% 累积积分
S = cumtrapz(x, diff);
S = [0; S];  % 初始值为0
% 计算被积函数
integrand = an .* exp(-S);
% 计算积分
I = trapz(x, integrand);
end

% 求解给定BV下的W
function W = solve_W_for_BV(BV, Wmin_cm, Wmax_cm, grid_points)
% 定义目标函数
f = @(W) ionization_integral_for_W(W, BV, grid_points) - 1.0;
% 使用fzero求解
W = fzero(f, [Wmin_cm, Wmax_cm]);
end