% 绘制电离积分Ion(V)对比图 - 版本2
% 对比MATLAB计算结果与Medici仿真结果
% 使用参数：W = 70 μm, N = 2.7901e14 cm^-3
% 本版本使用电场分布 E(x) = qN(W-x)/eps_s * (V/BV)

%% 常量定义
global a_n b_n a_p b_p q eps0 eps_r eps_s;
a_n = 7.03e5;        % cm^-1
b_n = 1.231e6;       % V/cm
a_p = 1.582e6;       % cm^-1
b_p = 2.036e6;       % V/cm
q = 1.602e-19;       % C
eps0 = 8.854e-14;    % F/cm
eps_r = 11.7;
eps_s = eps0 * eps_r;

%% 器件参数
W_cm = 70e-4;        % 70 μm = 70×10^-4 cm
N_dop = 2.7901e14;   % cm^-3
grid_points = 20000; % 网格点数

%% 计算电子电离系数
function an = alpha_n(E)
global a_n b_n;
    E = max(E, 1e-12);
    an = a_n * exp(-b_n ./ E);
end

%% 计算空穴电离系数
function ap = alpha_p(E)
global a_p b_p;
    E = max(E, 1e-12);
    ap = a_p * exp(-b_p ./ E);
end

%% 计算给定外加电压V下的电离积分
% 使用电场分布 E(x) = qN(W-x)/eps_s * (V/V_ref)
% 其中V_ref是参考电压，使得在V=V_ref时E(0)=qNW/eps_s
function I = ionization_integral_for_V(V, W_cm, N_dop, grid_points)
global eps_s q;

% 计算最大电场 (在x=0处)
% E_max = q * N_dop * W_cm / eps_s * scaling_factor
% 为了匹配Medici的BV=646.1V，我们需要找到合适的scaling
E_max_full = q * N_dop * W_cm / eps_s;  % 当耗尽区充满整个W时的最大电场

% 使用比例关系：电场与电压成正比
% 找到使Ion=1的参考电压
persistent V_ref;
if isempty(V_ref)
    % 第一次运行时，计算参考电压
    V_ref = find_V_for_ionization_one(W_cm, N_dop, grid_points);
    fprintf('参考电压 (Ion=1): %.2f V\n', V_ref);
end

% 电场比例因子
if V_ref > 0
    scale = V / V_ref;
else
    scale = V / 646.1;  % 使用Medici的BV作为默认值
end

% 生成空间网格
x = linspace(0, W_cm, grid_points)';
% 电场分布
E = E_max_full * (1 - x/W_cm) * scale;

% 计算电离系数
an = alpha_n(E);
an = an(:);
ap = alpha_p(E);
ap = ap(:);

% 计算差值
diff = an - ap;
diff = diff(:);

% 累积积分
S = cumtrapz(x, diff);
S = S(:);
if length(S) < length(x)
    S = [0; S];
end
S = S(1:length(an));

% 计算被积函数
integrand = an .* exp(-S);

% 计算积分
I = trapz(x, integrand);
end

%% 找到使电离积分=1的电压
function V_ref = find_V_for_ionization_one(W_cm, N_dop, grid_points)
global eps_s q a_n b_n a_p b_p;

E_max_full = q * N_dop * W_cm / eps_s;

% 定义目标函数
function I = ion_int(scale)
    x = linspace(0, W_cm, grid_points)';
    E = E_max_full * (1 - x/W_cm) * scale;
    an = a_n * exp(-b_n ./ max(E, 1e-12));
    ap = a_p * exp(-b_p ./ max(E, 1e-12));
    diff = an - ap;
    S = cumtrapz(x, diff);
    S = [0; S(1:end-1)];
    integrand = an .* exp(-S);
    I = trapz(x, integrand) - 1.0;
end

% 使用fzero求解
scale_ref = fzero(@ion_int, [0.1, 2.0]);

% 参考电压与scale成正比 (近似)
% 实际关系中 V = integral(E dx) = E_max_full * scale * W_cm / 2
V_ref = E_max_full * scale_ref * W_cm / 2;
end

%% 读取Medici仿真数据
excel_file = 'd:\micro_courseDesign\仿真\设定650_步长0.2_击穿电压646.1\设定650_步长0.2_击穿电压646.1.xlsx';
medici_data = readtable(excel_file);
V_medici = medici_data.('VoltageV_K__V_');  % 外加电压V
Ion_medici = medici_data.('ExtractedExpression_testn_');  % 电离积分Ion

%% 计算MATLAB电离积分
% 使用与Medici相同的电压点
V_matlab = V_medici;
Ion_matlab = zeros(size(V_matlab));

fprintf('计算MATLAB电离积分...\n');
for i = 1:length(V_matlab)
    V = V_matlab(i);
    if V > 0
        Ion_matlab(i) = ionization_integral_for_V(V, W_cm, N_dop, grid_points);
    else
        Ion_matlab(i) = 0;
    end
end

%% 绘图
figure('Position', [100, 100, 800, 600]);

% Medici仿真数据 - 散点图
scatter(V_medici, Ion_medici, 50, 'r', 'filled', 'MarkerFaceAlpha', 0.6, 'DisplayName', 'Medici Simulation');
hold on;

% MATLAB计算结果 - 连续曲线
plot(V_matlab, Ion_matlab, 'b-', 'LineWidth', 2, 'DisplayName', 'MATLAB Calculation');

% 添加击穿电压标记线（Medici实际击穿电压646.1V）
xline(646.1, '--k', 'LineWidth', 1.5, 'Alpha', 0.5, 'DisplayName', 'Breakdown Voltage (646.1V)');

% 添加Ion=1的水平线
yline(1, '--g', 'LineWidth', 1.5, 'Alpha', 0.5, 'DisplayName', 'Ion = 1');

hold off;

% 设置坐标轴
xlabel('Applied Voltage V (V)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Ionization Integral I_{on}', 'FontSize', 14, 'FontWeight', 'bold');
title('Ionization Integral vs Applied Voltage', 'FontSize', 16, 'FontWeight', 'bold');

% 设置图例
legend('Location', 'northwest', 'FontSize', 12);

% 设置网格
grid on;
set(gca, 'FontSize', 12, 'LineWidth', 1.5);

% 设置坐标轴范围
xlim([0, max(V_medici)*1.05]);
ylim([0, max(max(Ion_medici), max(Ion_matlab))*1.1]);

% 添加参数标注
annotation_text = sprintf('Parameters:\nW = 70 μm\nN = 2.7901×10^{14} cm^{-3}');
text(0.65, 0.25, annotation_text, 'Units', 'normalized', 'FontSize', 11, ...
    'BackgroundColor', 'white', 'EdgeColor', 'black', 'Margin', 5);

%% 保存图片
plot_dir = 'd:\micro_courseDesign\plot';
if ~exist(plot_dir, 'dir')
    mkdir(plot_dir);
end

% 保存为PNG
saveas(gcf, fullfile(plot_dir, 'Ion_V_comparison.png'));
% 保存为JPG
saveas(gcf, fullfile(plot_dir, 'Ion_V_comparison.jpg'));

fprintf('图片已保存到: %s\n', plot_dir);
fprintf('  - Ion_V_comparison.png\n');
fprintf('  - Ion_V_comparison.jpg\n');

%% 显示一些关键数据点
fprintf('\n关键数据点对比:\n');
fprintf('%-10s %-15s %-15s %-15s\n', 'V (V)', 'Medici Ion', 'MATLAB Ion', 'Relative Error');
fprintf('%s\n', repmat('-', 1, 60));

% 选择一些关键电压点
key_V = [100, 300, 500, 600, 640, 646.1, 650, 700];
for V_target = key_V
    [~, idx] = min(abs(V_medici - V_target));
    V_val = V_medici(idx);
    Ion_med = Ion_medici(idx);
    Ion_mat = Ion_matlab(idx);
    if Ion_med > 0
        rel_err = abs(Ion_mat - Ion_med) / Ion_med * 100;
    else
        rel_err = 0;
    end
    fprintf('%-10.1f %-15.6f %-15.6f %-15.2f%%\n', V_val, Ion_med, Ion_mat, rel_err);
end
