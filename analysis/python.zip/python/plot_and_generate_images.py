import os
import numpy as np
import matplotlib.pyplot as plt

csv_path = 'BV_W_N.csv'
if not os.path.exists(csv_path):
    import subprocess
    subprocess.check_call(['python', 'compute_N_dense.py'])

data = np.loadtxt(csv_path, skiprows=1)
BV = data[:,0]
W_um = data[:,1]
N = data[:,2]

# fit functions on log-log
def fit_power(x,y):
    logx = np.log(x)
    logy = np.log(y)
    p, logC = np.polyfit(logx, logy, 1)
    C = np.exp(logC)
    return C, p

C_N, p_N = fit_power(BV, N)
C_W, p_W = fit_power(BV, W_um)
C_NW, p_NW = fit_power(N, W_um)

# Save fit summary
with open('fit_coeffs.txt','w',encoding='utf-8') as f:
    f.write(f'N(BV): N = {C_N:.6g} * BV^{p_N:.6f}\n')
    f.write(f'W(BV): W = {C_W:.6g} * BV^{p_W:.6f}\n')
    f.write(f'W(N): W = {C_NW:.6g} * N^{p_NW:.6f}\n')

# plot N vs BV
plt.figure(figsize=(6,4))
plt.loglog(BV, N, 'o', markersize=4, label='data')
BV_line = np.linspace(BV.min(), BV.max(), 200)
plt.loglog(BV_line, C_N*BV_line**p_N, '-', label=f'fit: N={C_N:.3g}*BV^{p_N:.4f}')
plt.xlabel('BV (V)')
plt.ylabel('N (cm^-3)')
plt.title('N vs BV (log-log)')
plt.legend()
plt.grid(True, which='both', ls='--', lw=0.5)
plt.tight_layout()
plt.savefig('fit_N_vs_BV.png', dpi=150)
plt.close()

# plot W vs BV
plt.figure(figsize=(6,4))
plt.loglog(BV, W_um, 'o', markersize=4, label='data')
plt.loglog(BV_line, C_W*BV_line**p_W, '-', label=f'fit: W={C_W:.3g}*BV^{p_W:.4f}')
plt.xlabel('BV (V)')
plt.ylabel('W (um)')
plt.title('W vs BV (log-log)')
plt.legend()
plt.grid(True, which='both', ls='--', lw=0.5)
plt.tight_layout()
plt.savefig('fit_W_vs_BV.png', dpi=150)
plt.close()

# plot W vs N
plt.figure(figsize=(6,4))
plt.loglog(N, W_um, 'o', markersize=4, label='data')
N_line = np.logspace(np.log10(N.min()), np.log10(N.max()), 200)
plt.loglog(N_line, C_NW*N_line**p_NW, '-', label=f'fit: W={C_NW:.3g}*N^{p_NW:.4f}')
plt.xlabel('N (cm^-3)')
plt.ylabel('W (um)')
plt.title('W vs N (log-log)')
plt.legend()
plt.grid(True, which='both', ls='--', lw=0.5)
plt.tight_layout()
plt.savefig('fit_W_vs_N.png', dpi=150)
plt.close()

print('Saved images: fit_N_vs_BV.png, fit_W_vs_BV.png, fit_W_vs_N.png')
print(f'N fit: C={C_N:.6g}, p={p_N:.6f}')
print(f'W fit: C={C_W:.6g}, p={p_W:.6f}')
print(f'W-N fit: C={C_NW:.6g}, p={p_NW:.6f}')
