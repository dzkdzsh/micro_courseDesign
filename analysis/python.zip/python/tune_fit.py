import numpy as np
from scipy.integrate import cumulative_trapezoid, trapezoid
from scipy.optimize import brentq
import time

# constants
a_n = 7.03e5
b_n = 1.231e6
a_p = 1.582e6
b_p = 2.036e6
q = 1.602e-19
eps0 = 8.854e-14
eps_r = 11.7
eps_s = eps0 * eps_r


def alpha_n(E):
    E = np.maximum(E, 1e-12)
    return a_n * np.exp(-b_n / E)

def alpha_p(E):
    E = np.maximum(E, 1e-12)
    return a_p * np.exp(-b_p / E)


def ionization_integral_for_W(W_cm, BV, grid_points):
    x = np.linspace(0, W_cm, grid_points)
    E = 2.0 * BV * (W_cm - x) / (W_cm**2)
    an = alpha_n(E)
    ap = alpha_p(E)
    diff = an - ap
    S = cumulative_trapezoid(diff, x, initial=0.0)
    integrand = an * np.exp(-S)
    I = trapezoid(integrand, x)
    return I


def solve_W_for_BV(BV, Wmin_cm, Wmax_cm, grid_points):
    f = lambda W: ionization_integral_for_W(W, BV, grid_points) - 1.0
    return brentq(f, Wmin_cm, Wmax_cm, xtol=1e-10, maxiter=300)


def run_config(grid_points, n_BV):
    BV_list = np.linspace(400, 1600, n_BV)
    W_solutions = []
    N_solutions = []
    start = time.time()
    for BV in BV_list:
        W_fulop_um = 0.0257 * (BV**(7.0/6.0))
        W_guess_cm = W_fulop_um * 1e-4
        Wmin = max(1e-6, W_guess_cm * 0.2)
        Wmax = max(Wmin*10, W_guess_cm * 4.0)
        try:
            W = solve_W_for_BV(BV, Wmin, Wmax, grid_points)
        except Exception:
            W = solve_W_for_BV(BV, Wmin*0.05, Wmax*20, grid_points)
        N = 2.0 * eps_s * BV / (q * W**2)
        W_solutions.append(W)
        N_solutions.append(N)
    elapsed = time.time() - start
    BV = np.array(BV_list)
    N = np.array(N_solutions)
    p_N, logC_N = np.polyfit(np.log(BV), np.log(N), 1)
    C_N = np.exp(logC_N)
    return p_N, C_N, elapsed


if __name__ == '__main__':
    configs = [ (10000,13), (20000,13), (40000,13), (10000,41), (20000,41) ]
    results = []
    for gp, nbv in configs:
        print(f"Running grid={gp}, BVcount={nbv} ...")
        p, C, t = run_config(gp, nbv)
        print(f"  exponent={p:.6f}, C={C:.6g}, time={t:.1f}s")
        results.append((gp, nbv, p, C, t))
    print('\nAll results:')
    for r in results:
        print(r)
