说明：
1. 目录 `analysis` 包含用于基于 Chynoweth 模型的数值计算与拟合的脚本，用以比较论文 Eq.(3)-(5) 的经验式。
2. 脚本：
   - `reproduce_eq345.py`：主脚本，求解离子化积分并对 BV-W、BV-N 做对数线性拟合，输出 `fit_results.txt`。
   - `compute_N_dense.py`：对 BV 做密集采样并保存 `BV_W_N.csv`，用于更精细的拟合与区间敏感性分析。
   - `plot_and_generate_images.py`：读取 `BV_W_N.csv`，生成拟合系数文件 `fit_coeffs.txt` 及三张对比图 `fit_N_vs_BV.png`, `fit_W_vs_BV.png`, `fit_W_vs_N.png`。
3. 运行步骤（在 `analysis` 目录下）：

```powershell
python -m pip install -r requirements.txt
python compute_N_dense.py
python plot_and_generate_images.py
```

4. 输出文件：`BV_W_N.csv`、`fit_coeffs.txt`、`fit_N_vs_BV.png`、`fit_W_vs_BV.png`、`fit_W_vs_N.png`、`fit_results.txt`。
