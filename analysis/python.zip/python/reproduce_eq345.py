import numpy as np
from scipy.integrate import cumulative_trapezoid, trapezoid
from scipy.optimize import brentq

# constants (units: length in cm, field in V/cm)
a_n = 7.03e5       # cm^-1
b_n = 1.231e6      # V/cm
a_p = 1.582e6      # cm^-1
b_p = 2.036e6      # V/cm
q = 1.602e-19      # C
eps0 = 8.854e-14   # F/cm
eps_r = 11.7
eps_s = eps0 * eps_r

def alpha_n(E):
    E = np.maximum(E, 1e-12)
    return a_n * np.exp(-b_n / E)

def alpha_p(E):
    E = np.maximum(E, 1e-12)
    return a_p * np.exp(-b_p / E)

def ionization_integral_for_W(W_cm, BV):
    x = np.linspace(0, W_cm, 10000)
    E = 2.0 * BV * (W_cm - x) / (W_cm**2)   # V/cm
    an = alpha_n(E)
    ap = alpha_p(E)
    diff = an - ap
    S = cumulative_trapezoid(diff, x, initial=0.0)
    integrand = an * np.exp(-S)
    I = trapezoid(integrand, x)
    return I

def solve_W_for_BV(BV, Wmin_cm, Wmax_cm):
    f = lambda W: ionization_integral_for_W(W, BV) - 1.0
    return brentq(f, Wmin_cm, Wmax_cm, xtol=1e-8, maxiter=200)

def main():
    BV_list = np.linspace(400, 1600, 41)
    W_solutions = []
    N_solutions = []

    for BV in BV_list:
        W_fulop_um = 0.0257 * (BV**(7.0/6.0))    # μm, Fulop reference
        W_guess_cm = W_fulop_um * 1e-4
        Wmin = max(1e-6, W_guess_cm * 0.2)
        Wmax = max(Wmin*10, W_guess_cm * 4.0)
        try:
            W = solve_W_for_BV(BV, Wmin, Wmax)
        except Exception:
            W = solve_W_for_BV(BV, Wmin*0.05, Wmax*20)
        N = 2.0 * eps_s * BV / (q * W**2)
        W_solutions.append(W)
        N_solutions.append(N)

    BV = np.array(BV_list)
    W_um = np.array(W_solutions) * 1e4   # to μm
    N = np.array(N_solutions)

    p_W, logC_W = np.polyfit(np.log(BV), np.log(W_um), 1)
    C_W = np.exp(logC_W)
    p_N, logC_N = np.polyfit(np.log(BV), np.log(N), 1)
    C_N = np.exp(logC_N)
    p_NW, logC_NW = np.polyfit(np.log(N), np.log(W_um), 1)
    C_NW = np.exp(logC_NW)

    out = []
    out.append("拟合结果 (analysis 数值拟合):")
    out.append(f"W ≈ {C_W:.5g} * BV^{p_W:.5f} μm")
    out.append(f"N ≈ {C_N:.5g} * BV^{p_N:.5f} cm^-3")
    out.append(f"W ≈ {C_NW:.5g} * N^{p_NW:.5f} μm")
    out.append("\n数据点样例 (BV, W_um, N):")
    for b, w, n in zip(BV, W_um, N):
        out.append(f"{int(b)} V: {w:.6g} μm, {n:.6g} cm^-3")

    text = "\n".join(out)
    print(text)
    with open('fit_results.txt', 'w', encoding='utf-8') as f:
        f.write(text)

if __name__ == '__main__':
    main()
